<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Fjalla+One&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<link rel="stylesheet" href="<?php echo e(URL::asset('css/custom.css')); ?>">


</head>
<body>
    <?php $__env->startSection('header'); ?>
      <?php echo e(View::make('header')); ?>

    <?php echo $__env->yieldSection(); ?>
<div class="content">
<?php $__env->startSection('content'); ?>

 <?php echo $__env->yieldSection(); ?>
</div>
    

<?php $__env->startSection('footer'); ?>
<?php echo e(View::make('footer')); ?>

<?php echo $__env->yieldSection(); ?>
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
let type="<?php echo e(Session::get('alert-type')); ?>";
let err_msg="";

// alert(<?php echo e($errors); ?>);
// <?php if($errors->any()): ?>

// type='error';

//             <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
//                 alert(<?php echo e($error); ?>);
//             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
//                   
// <?php endif; ?>


//   alert(type);
  
//   toastr.success(type);
  if(type=="success"){
  		toastr.success("<?php echo e(Session::get('message')); ?>");
  }
 

 if(type=="warning"){
  		toastr.warning("<?php echo e(Session::get('message')); ?>");
 }


 if(type=="error"){
  		toastr.error("<?php echo e(Session::get('message')); ?>");
 }
 <?php echo e(Session::forget(['alert-type', 'message'])); ?>

    
   </script>
</body>
</html><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/master_layout.blade.php ENDPATH**/ ?>