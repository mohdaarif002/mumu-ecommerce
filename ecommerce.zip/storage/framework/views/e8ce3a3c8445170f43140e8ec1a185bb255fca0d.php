<nav class="navbar fixed-bottom navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Fixed bottom</a>
  </div>
</nav><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/footer.blade.php ENDPATH**/ ?>