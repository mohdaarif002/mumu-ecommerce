

<?php $__env->startSection('content'); ?>

<h3>Cart Items</h3>
<?php
$imageURL='img-url';
?>
<?php if(count($products)!=0): ?>
<div class=" container product-card">

<a class='btn btn-primary' href="/order-now">Order Now</a>
    <div class="row">
   
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3 inner-card">
                    
                                <div class="card ">
                                
                                    <img class="card-img-top card-image img-fluid img-thumbnail"  src="<?php echo e($product->$imageURL); ?>" alt="Card image">
                                            <div class="card-body ">
                                                <!-- <h4 class="card-title"><?php echo e(print_r($product)); ?></h4>
                                                <h4 class="card-title"><?php echo e(print_r($product->$imageURL)); ?></h4> -->
                                            
                                                <h4 class="card-title"><?php echo e($product->name); ?></h4>
                                                <p class="card-text">&#8377 <?php echo e($product->price); ?></p>
                                                <p class="card-text"><?php echo e($product->description); ?></p>
                                            </div>
                                <a class="btn btn-danger" href="/remove-product/<?php echo e($product->cartId); ?>"> Remove From Cart  </a> 

                                </div>
                            
                    </div> 
            
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>     
 </div>    
<a class='btn btn-primary' href="/order-now">Order Now</a>

<?php else: ?>
 <h5>Add Items to your cart.</h5>
 <?php endif; ?> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/cart_list.blade.php ENDPATH**/ ?>