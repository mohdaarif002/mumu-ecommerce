

<?php $__env->startSection('content'); ?>

<h3>My Orders</h3>
<?php
$imageURL='img-url';
?>
<?php if(count($products)!=0): ?>
<div class=" container product-card">

    <div class="row">
   
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3 inner-card">
                    
                                <div class="card ">
                                
                                    <img class="card-img-top card-image img-fluid img-thumbnail"  src="<?php echo e($product->$imageURL); ?>" alt="Card image">
                                            <div class="card-body ">
                                            
                                                <h4 class="card-title"><?php echo e($product->name); ?></h4>
                                                <p class="card-text">&#8377 <?php echo e($product->price); ?></p>
                                                <p class="card-text">Payment Option:<?php echo e($product->paymentOption); ?></p>
                                                <p class="card-text">Payment Status:<?php echo e($product->paymentStatus); ?></p>
                                                <p class="card-text">Order Status: <?php echo e($product->status); ?></p>
                                                <p class="card-text">Address : <?php echo e($product->paymentAddress); ?></p>
                                            </div>

                                </div>
                            
                    </div> 
            
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>     


<?php else: ?>
 <h5>No Order placed yet.</h5>
 <?php endif; ?> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/my_order.blade.php ENDPATH**/ ?>