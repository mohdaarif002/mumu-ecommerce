

<?php $__env->startSection('content'); ?>


<h3>Search Results</h3>

<div class=" container product-card">
    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-5 inner-card">
             <a href="/detail/<?php echo e($product['id']); ?>">
                       <div class="card ">
                      
                          <img class="card-img-top card-image img-fluid img-thumbnail"  src="<?php echo e($product['img-url']); ?>" alt="Card image">
                                  <div class="card-body ">
                                      <h4 class="card-title"><?php echo e($product['name']); ?></h4>
                                      <p class="card-text"><?php echo e($product['price']); ?></p>
                                      <p class="card-text"><?php echo e($product['description']); ?></p>
                                  </div>
                       </div>
              </a>         
             </div> 
          
             
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>     
</div>    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/search.blade.php ENDPATH**/ ?>