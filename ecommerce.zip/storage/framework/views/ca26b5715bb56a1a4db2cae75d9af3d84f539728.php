

<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row">
    <div class="col-sm-6">
     <img class='detail-img' src="<?php echo e($product['img-url']); ?>" alt="">
    </div>
    <div class="col-sm-6  detail-text" >
        <a href="/">Go Back</a>
        <h3><?php echo e($product['name']); ?></h3>
        <h3><?php echo e($product['price']); ?></h3>
        <h3><?php echo e($product['description']); ?></h3>

        <div class='row detail-buy-options'>
          <div class="col-6">
          <form action="/add_to_cart" method='POST'>
              <?php echo csrf_field(); ?>
              <input type="hidden" name="product_id" value='<?php echo e($product['id']); ?>' id="">
          
              <button class="btn btn-primary">Add to Cart</button>
            </form>
          </div>
            
            <div class="col-6">
              <form action="/buy-now" method='POST'>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value='<?php echo e($product['id']); ?>' id="">
            
                <button class="btn btn-success detail-btn">Buy Now</button>
              </form>
            
            </div>
           
        </div>
    </div>

</div>

</div>
 
  
   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/detail.blade.php ENDPATH**/ ?>