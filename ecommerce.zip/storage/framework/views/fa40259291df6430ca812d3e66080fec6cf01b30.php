

<?php $__env->startSection('content'); ?>
<div class="container-fluid product-container">
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">


 
    <div class="carousel-inner">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="carousel-item <?php echo e($product['id']==4?'active':''); ?>"> 
                  <a href="/detail/<?php echo e($product['id']); ?>">
                      <img src="<?php echo e($product['img-url']); ?>" class="d-block w-100" alt="">
                          <div class="carousel-caption d-none d-md-block">
                              <h5><?php echo e($product['name']); ?></h5>
                              <p><?php echo e($product['description']); ?></p>
                          </div>
                      </a>     
              </div>
              
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </div>
   
    <div class="carousel-indicators">
    <?php $count=0; ?>
  
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($count); ?>" class="<?php echo e($count==0?'active':''); ?>" aria-current="true" ></button>
    <?php $count+=1; ?> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  

    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"  data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
</div>
</div>
<h3>Trending Products</h3>

<div class=" container product-card">
  <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 inner-card">
             <a href="/detail/<?php echo e($product['id']); ?>">
                       <div class="card ">
                      
                          <img class="card-img-top card-image img-fluid img-thumbnail"  src="<?php echo e($product['img-url']); ?>" alt="Card image">
                                  <div class="card-body ">
                                      <h4 class="card-title"><?php echo e($product['name']); ?></h4>
                                      <p class="card-text">&#8377 <?php echo e($product['price']); ?></p>
                                      <p class="card-text"><?php echo e($product['description']); ?></p>
                                  </div>
                       </div>
              </a>         
             </div> 
          
             
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>     
  </div> 
</div>    



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\ecommerce\resources\views/product.blade.php ENDPATH**/ ?>